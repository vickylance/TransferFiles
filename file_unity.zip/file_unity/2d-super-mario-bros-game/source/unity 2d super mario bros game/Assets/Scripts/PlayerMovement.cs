﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {
    // Movement Properties
    public float moveSpeed = 15;
    [Range(0,1)] public float sliding = 0.9f;
    public float jumpForce = 1200;
    
    bool IsGrounded() {
        // noobtuts.com isGrounded function

        // Get Bounds and Cast Range (10% of height)
        Bounds bounds = collider2D.bounds;
        float range = bounds.size.y * 0.1f;
        
        // Calculate a position slightly below the collider
        Vector2 v = new Vector2(bounds.center.x,
                                bounds.min.y - range);

        // Linecast upwards
        RaycastHit2D hit = Physics2D.Linecast(v, bounds.center);
        
        // Was there something in-between, or did we hit ourself?
        return (hit.collider.gameObject != gameObject);
    }

    void FixedUpdate () {
        // Horizontal Movement
        float h = Input.GetAxis("Horizontal");
        Vector2 v = rigidbody2D.velocity;
        if (h != 0) {
            // Move Left/Right
            rigidbody2D.velocity = new Vector2(h * moveSpeed, v.y);
            transform.localScale = new Vector2(Mathf.Sign(h), transform.localScale.y);
        } else {
            // Get slower (Super Mario style sliding motion)
            rigidbody2D.velocity = new Vector2(v.x * sliding, v.y);
        }
        GetComponent<Animator>().SetFloat("Speed", Mathf.Abs(h));

        // Vertical Movement (Jumping)
        bool grounded = IsGrounded();
        if(Input.GetKey(KeyCode.UpArrow) && grounded)
            rigidbody2D.AddForce(Vector2.up * jumpForce);
        GetComponent<Animator>().SetBool("Jumping", !grounded);
    }
}