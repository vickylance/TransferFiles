﻿using UnityEngine;
using System.Collections;

public class UVScroll : MonoBehaviour {
    public Vector2 speed;
 
    void LateUpdate() {
        renderer.material.mainTextureOffset = speed * Time.time;
    }
}
