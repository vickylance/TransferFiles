﻿using UnityEngine;
using System.Collections;

public class ContinuousVelocity : MonoBehaviour {
    // The Velocity
    public Vector2 velocity;

    void FixedUpdate() {
        rigidbody2D.velocity = velocity;
    }
}
