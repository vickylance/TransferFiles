﻿using UnityEngine;
using System.Collections;

public class Frog : MonoBehaviour {
    // Jump Speed
    public float speed = 1;

    // Size of one jump
    public float jumpSize = 17;
        
    // Current Jump goal
    Vector2 jump = Vector2.zero;

    // Is the Frog currently jumping?
    public bool isJumping() {
        return jump != Vector2.zero;
    }

    // FixedUpdate for Physics Stuff
    void FixedUpdate () {
        // Currently jumping?
        if (jump != Vector2.zero)
        {
            // Currently jumping?
            if (jump != Vector2.zero) {
                // Jump a bit, set new Position
                Vector2 pos = transform.position;
                Vector2 newPos = Vector2.MoveTowards(pos, pos+jump, speed);
                transform.position = newPos;

                // Decrease jump vector a bit
                Vector2 step = newPos - pos;
                jump -= step;
            }
        }
        // Otherwise allow for next jump
        else
        {
            if (Input.GetKey(KeyCode.UpArrow))
                jump = Vector2.up * jumpSize;
            else if (Input.GetKey(KeyCode.RightArrow))
                jump = Vector2.right * jumpSize;
            else if (Input.GetKey(KeyCode.DownArrow))
                jump = -Vector2.up * jumpSize;
            else if (Input.GetKey(KeyCode.LeftArrow))
                jump = -Vector2.right * jumpSize;
        }

        // Animation Parameters
        GetComponent<Animator>().SetFloat("X", jump.x);
        GetComponent<Animator>().SetFloat("Y", jump.y);
        if (jump == Vector2.zero)
            GetComponent<Animator>().speed = 0;
        else
            GetComponent<Animator>().speed = 1;
    }

    void OnCollisionEnter2D(Collision2D coll) {
        // Game Over
        Destroy(gameObject);
    }
}
