﻿using UnityEngine;
using System.Collections;

public class Platform : MonoBehaviour {

    void OnTriggerEnter2D(Collider2D coll) {
        // Frog? Then make it a Child
        if (coll.name == "Frog")
            coll.transform.parent = transform;
    }
    
    void OnTriggerExit2D(Collider2D coll) {
        coll.transform.parent = null;        
    }
}
