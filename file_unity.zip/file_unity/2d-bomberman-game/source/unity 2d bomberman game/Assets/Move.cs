﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour {
    public float speed = 0.1f;

    Animator anim;

    void Start() {
        anim = GetComponent<Animator>();
    }

	void FixedUpdate () {
        Vector2 dir = Vector2.zero;
        if (Input.GetKey(KeyCode.UpArrow)) {
            anim.SetInteger("Direction", 0);
            dir.y = speed;
        } else if (Input.GetKey(KeyCode.RightArrow)) {
            anim.SetInteger("Direction", 1);
            dir.x = speed;
        } else if (Input.GetKey(KeyCode.DownArrow)) {
            anim.SetInteger("Direction", 2);
            dir.y = -speed;
        } else if (Input.GetKey(KeyCode.LeftArrow)) {
            anim.SetInteger("Direction", 3);
            dir.x = -speed;
        } else {
            // idle
            anim.SetInteger("Direction", 4);
        }
        transform.Translate(dir);
    }
}