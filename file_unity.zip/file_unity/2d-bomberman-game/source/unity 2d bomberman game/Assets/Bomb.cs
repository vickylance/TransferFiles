﻿using UnityEngine;
using System.Collections;

public class Bomb : MonoBehaviour {
    // Time after which the bomb explodes
    float time = 3.0f;

    // Explosion Prefab
    public GameObject explosion;

    void Start () {
        // Call the Explode function after a few seconds
        Invoke("Explode", time);
    }
    
    void Explode() {
        // Remove Bomb from game
        Destroy(gameObject);

        // Spawn Explosion
        Instantiate(explosion,
                    transform.position,
                    Quaternion.identity);

        // Destroy stuff
        Vector2 pos = transform.position;
        Block.destroyBlockAt(pos.x,   pos.y);   // same
        Block.destroyBlockAt(pos.x,   pos.y+1); // top
        Block.destroyBlockAt(pos.x+1, pos.y);   // right
        Block.destroyBlockAt(pos.x,   pos.y-1); // bottom
        Block.destroyBlockAt(pos.x-1, pos.y);   // left
    }
}