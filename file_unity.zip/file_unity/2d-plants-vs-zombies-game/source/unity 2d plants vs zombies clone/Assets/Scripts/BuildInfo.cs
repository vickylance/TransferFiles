﻿using UnityEngine;
using System.Collections;

public class BuildInfo : MonoBehaviour {
    
        public Texture previewImage;
        public int price;
}
