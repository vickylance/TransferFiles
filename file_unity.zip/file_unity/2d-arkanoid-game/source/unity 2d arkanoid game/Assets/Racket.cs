﻿using UnityEngine;
using System.Collections;

public class Racket : MonoBehaviour {

    public float speed = 3;

    void FixedUpdate () {
        // Left key pressed?
        if (Input.GetKey(KeyCode.LeftArrow)) {
            transform.Translate(new Vector2(-speed, 0));
        }

        // Right key pressed?
        if (Input.GetKey(KeyCode.RightArrow)) {
            transform.Translate(new Vector2(speed, 0));
        }
    }
}